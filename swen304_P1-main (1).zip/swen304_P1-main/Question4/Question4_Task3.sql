/*
Select BankName and City from Banks
Join HASACCOUNTS and ROBBERS using common columns
Only Return results where NickName is 'Al Capone'
*/

SELECT BankName, City 
From BANKS 
NATURAL JOIN HASACCOUNTS 
NATURAL JOIN ROBBERS 
WHERE NickName = 'Al Capone';
