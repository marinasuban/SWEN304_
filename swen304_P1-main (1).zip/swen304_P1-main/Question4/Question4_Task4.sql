/*
Select BankName, City, NoAccounts from BANKS table where city is not Chicago
order records by NoAccounts (increasing order)
*/

SELECT BankName, City, NoAccounts
From BANKS
WHERE BankName NOT IN (SELECT BankName FROM BANKS WHERE City =
'Chicago')
ORDER BY NoAccounts;
