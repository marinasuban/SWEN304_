/*
Get Description, RobberId, NickName from the ROBBERS table
join HASSKILLS and SKILLS table using common columns
return records in alaphabetical order of description value
*/

SELECT Description, RobberId, NickName
From ROBBERS
NATURAL JOIN HASSKILLS
NATURAL JOIN SKILLS
ORDER BY Description;
