/*
Select RobberId, NickName, Age, Description from ROBBERS table and join to HASSKILLS and SKILLS table using common column
Only return records where age is greater than 40
*/

SELECT RobberId, NickName, Age, Description
From ROBBERS
NATURAL JOIN HASSKILLS
NATURAL JOIN SKILLS
WHERE Age > 40;
