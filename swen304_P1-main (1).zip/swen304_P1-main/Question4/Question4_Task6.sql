/*
Select RobberId, NickName, NoYears from Robbers table where noYears is greater than 10
*/

SELECT RobberId, NickName, NoYears
From ROBBERS
WHERE NoYears>10;
