/*
SELECT RobberId, NickName, NoYearsNotInPrison from robbers where NoYearsNotInPrison is Age less NoYears
Only return records where NoYears is greater than half of age
*/

SELECT RobberId, NickName, (Age - NoYears) AS NoYearsNotInPrison
From ROBBERS 
WHERE (Age/2)<NoYears;
