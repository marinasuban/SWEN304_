/*
Select BankName, City From BANKS table that are not in ROBBERIES table
*/

SELECT BankName, City From BANKS 
WHERE (BankName, City)
NOT IN(SELECT BankName, City FROM ROBBERIES);
