/*
From ACCOMPLICES table get robberId and earning (sum of shares for each robberId) and save result as Total
Join Total to ROBBERS using common columns
return records of RobberId, NickName, Earning from Total where earning is greater than $40,000 and order by descending amounts
*/

SELECT RobberId, NickName, Earning 
From (SELECT RobberId, SUM(Share) AS Earning FROM ACCOMPLICES GROUP BY RobberId) AS Total 
NATURAL JOIN ROBBERS 
WHERE Earning > 40000 
ORDER BY Earning DESC;
