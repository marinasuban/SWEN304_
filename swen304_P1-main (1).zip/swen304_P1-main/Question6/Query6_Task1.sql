/*
Get records of robbers from accomplicies table for robbers who have served no years in prison
join to robbers table using common column
group records by RobberId, NickName and save result as unpenalisedRobbersStatistic
return nickname of robbers in unpenalisedRobbersStatistic where they have a robberyCount higher than the average
*/

SELECT NickName 
FROM( SELECT RobberId, NickName, COUNT(RobberId) as robberyCount, SUM(Share) as totalShare,AVG(COUNT(RobberId)) over () AS averageRobberiesCommitted from ACCOMPLICES 
NATURAL JOIN ROBBERS 
WHERE NoYears = 0 
GROUP BY(RobberId, NickName)) AS unpenalisedRobbersStatistic 
WHERE robberyCount > averageRobberiesCommitted 
ORDER BY totalShare DESC;
