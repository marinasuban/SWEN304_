/*
We Join BANKS and ROBBERIES using common columns
Group by Security
and then return records containing SecurityLevel, totalRobberies, averageAmountStolen
*/

SELECT Security AS SecurityLevel, COUNT(Security) as totalRobberies, AVG(Amount) AS averageAmountStolen FROM BANKS 
NATURAL JOIN ROBBERIES 
GROUP BY Security;
