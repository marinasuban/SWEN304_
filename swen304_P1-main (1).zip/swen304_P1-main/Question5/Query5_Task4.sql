/*
Return records containing BankName, City, Date from ROBBERIES table with the greatest amount of money stolen from each city
*/

SELECT BankName, City, Date FROM ROBBERIES 
WHERE (City, Amount) = ANY(SELECT City, MAX(Amount) FROM ROBBERIES GROUP BY(City));
