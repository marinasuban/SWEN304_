/*
Group records with same BankName, City in ACCOMPLICES table
Return BankName, City where the number of Unique robberId in each group is equal to the number of robbers in the ROBBERS Table (unique because primary key)
*/

SELECT BankName, City FROM ACCOMPLICES 
GROUP BY(BankName, City)
HAVING COUNT(DISTINCT RobberId) = (SELECT COUNT(RobberId) FROM ROBBERS);
