/* 
Get RobberId and NickName from Robbers table 
then exclude any records with the same RobberId and NickName from HasAccounts table
Join outcome to accomplices and robbers table using common columns
*/

SELECT RobberId, NickName FROM ROBBERS
EXCEPT
SELECT RobberId, NickName FROM HASACCOUNTS
NATURAL JOIN ACCOMPLICES
NATURAL JOIN ROBBERS;
