/*
From HASSKILLS table select all robberId that appear 2 or more time and save to twoSkill
Join ROBBERS, SKILLS, HASSKILLS table using common columns
Return records containing RobberId, NickName, Description where preference is 1
*/

SELECT RobberId, NickName, Description 
FROM (SELECT RobberId FROM HASSKILLS GROUP BY(RobberId) HAVING COUNT(RobberId) >=2) as TwoSkill 
NATURAL JOIN ROBBERS 
NATURAL JOIN SKILLS 
NATURAL JOIN HASSKILLS 
WHERE Preference = 1;
