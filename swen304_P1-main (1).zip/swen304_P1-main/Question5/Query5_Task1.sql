/* 
Get Bankname, City and Year from Plans table 
then exclude any records with the same Bankname, City and Year from Robberies table
Save outcome as Foo
Select Bankname and City from records in Foo
*/

SELECT BankName,City FROM(
SELECT BankName, City, (SELECT EXTRACT (YEAR FROM PlannedDate)) FROM PLANS
EXCEPT
SELECT BankName, City, (SELECT EXTRACT (YEAR FROM Date)) FROM ROBBERIES) 
AS Foo;
